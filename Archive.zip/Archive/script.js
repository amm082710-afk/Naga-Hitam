let paketDipilih = "";
let hargaDipilih = "";

function pilihPaket(paket, harga) {
    paketDipilih = paket;
    hargaDipilih = harga;
    // highlight pilihan — cari semua paket-card lalu beri style
    document.querySelectorAll('.paket-card').forEach(c => c.style.borderColor = '#333');
    // find clicked card by text matching paket (simple)
    const cards = [...document.querySelectorAll('.paket-card')];
    for(const c of cards){
      if(c.innerText.includes(paket.split(' ')[0])) {
        c.style.borderColor = '#ff4d00';
      }
    }
    alert("Paket dipilih: " + paket);
}

function kirimWA() {
    const id = document.getElementById("idUser").value.trim();
    const wa = document.getElementById("waUser").value.trim();

    if (!id || !wa || !paketDipilih) {
        alert("Lengkapi semua data & pilih paket!");
        return;
    }

    const admin = "6281234567890"; // GANTI NOMOR ADMIN (format internasional tanpa +, contoh 62812...)

    const pesan = `🔥 *NAGA HITAM TOPUP* 🔥

ID: ${id}
WhatsApp: ${wa}

Paket: ${paketDipilih}
Harga: Rp ${hargaDipilih}

Mohon diproses.`;

    const encoded = encodeURIComponent(pesan);
    window.location.href = `https://wa.me/${admin}?text=${encoded}`;
}